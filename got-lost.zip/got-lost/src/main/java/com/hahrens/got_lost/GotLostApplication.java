package com.hahrens.got_lost;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GotLostApplication {

	public static void main(String[] args) {
		SpringApplication.run(GotLostApplication.class, args);
	}

}
